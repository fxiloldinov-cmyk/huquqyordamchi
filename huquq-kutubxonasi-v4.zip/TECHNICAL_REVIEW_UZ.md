# Uzbekistan Law Library — birinchi texnik ko'rik

## Arxiv tarkibi
- `index.html`, `styles.css`, `app.js`: statik frontend.
- `netlify/functions/chat.js`: Netlify AI backend.
- `chat.js`: eski loyiha tuzilmasi uchun mos nusxa; asosiy Netlify deploy `netlify/functions/chat.js` faylidan foydalanadi.
- `telegram_bot/`: Telegram bot.

## Ushbu ko'rikda qilingan o'zgarishlar
1. Backenddagi eskirgan `gemini-1.5-flash` nomi sozlanadigan `GEMINI_MODEL` bilan almashtirildi; standart qiymat `gemini-2.5-flash`.
2. API kaliti faqat server muhitidan olinadi; kalit yo'q bo'lsa, soxta AI javobi qaytarilmaydi.
3. So'rov JSON, xabarlar soni, rol va uzunlik tekshiruvlari qo'shildi.
4. Provider xatosining ichki matni foydalanuvchiga oshkor qilinmaydi.
5. Huquqiy prompt tekshirilmagan modda va havolalarni uydirmaslikni alohida belgilaydi.
6. `.env.example` yaratildi; haqiqiy maxfiy kalitlar bu faylga kiritilmagan.

## Hali bajarilishi kerak
- `app.js` ichidagi lokal API kaliti bilan to'g'ridan-to'g'ri Gemini chaqirish imkoniyatini production versiyada o'chirish yoki faqat developer rejimida qoldirish.
- Telegram botdagi `gemini-1.5-flash` va `google-generativeai` SDK qismini amaldagi `google-genai` SDKga ko'chirish va alohida sinash.
- Hayotiy vaziyatlar katalogidagi huquqiy da'volarni amaldagi rasmiy qonun matni bilan modda-modda tekshirish.
- Lex.uz hujjatlarini olish/yangilash usulini rasmiy foydalanish shartlariga mos tanlash; avtomatik qirib olishni ruxsat va texnik imkoniyat tekshirilmasdan yoqmaslik.
- RAG qidiruv, manba ko'rsatish, qonun tahrirlari tarixi va kuchga kirish sanalarini qo'shish.
- Login, maxfiylik siyosati, rate limiting, loglarni tozalash va zaxira nusxalashni ishlab chiqish.
- Hujjat generatori uchun andozalarni yurist bilan tekshirish.
- Unit/integration testlar va deploydan oldingi xavfsizlik tekshiruvini o'tkazish.

## Deploy uchun kerak
Netlify Environment Variables:
- `GEMINI_API_KEY`: Google AI Studio API kaliti.
- `GEMINI_MODEL`: provayderda mavjud model identifikatori.

API kalitini frontend, `.env.example`, README yoki ochiq repozitoriyga joylashtirmang.

## Muhim cheklov
Bu paket — birinchi texnik tuzatish va ko'rik, to'liq tayyor yoki huquqiy jihatdan tasdiqlangan mahsulot emas. Qonun moddalarini va tayyor huquqiy javoblarni amaldagi rasmiy manbalar bilan tekshirish alohida bosqich bo'lib qoladi.

## Ikkinchi tuzatish (frontend va Telegram)
- Frontenddan Gemini API'ga bevosita murojaat qilish yo'li olib tashlandi.
- `localStorage` ichida foydalanuvchi API kalitini saqlash va sozlash oynasidagi kalit kiritish olib tashlandi.
- Frontenddagi AI chat faqat `/api/chat` backend endpointidan foydalanadi.
- AI sozlamalari oynasi administratorning server muhitini sozlashi kerakligini tushuntiradi.
- Telegram botning eski `google-generativeai` SDK chaqiruvi `google-genai` SDK uslubiga ko'chirildi; model `GEMINI_MODEL` orqali sozlanadi.
- API kaliti yo'q bo'lsa bot taxminiy huquqiy maslahat qaytarmaydi.

## Sinov holati
- JavaScript sintaksis tekshiruvi va Python bytecode compile tekshiruvi bajarilishi kerak.
- Haqiqiy Gemini API, Netlify deploy, Telegram polling, huquqiy manbalar va foydalanuvchi oqimi uchun jonli integratsion testlar hali talab qilinadi.

## Uchinchi bosqich (rasmiy qonun qidiruvi)
- Kodekslar bo'limiga Lex.uz rasmiy qidiruviga olib boradigan qidiruv shakli qo'shildi.
- Qidiruv foydalanuvchi kiritgan so'rovni URL-encode qilib, faqat `https://lex.uz` domenidagi qidiruvga yuboradi.
- Bu integratsiya Lex.uz API yoki jonli qonun bazasini saytda indekslash emas; foydalanuvchi rasmiy saytga o'tadi.
- Mobil ekranda qidiruv maydoni va tugma vertikal joylashadi.


## V4 — sayt ichidagi qidiruv prototipi
- Kodekslar bo‘limidagi tashqi qidiruv ichki katalog qidiruvi bilan almashtirildi.
- Qidiruv mavjud kodekslar katalogi va hayotiy vaziyatlar ro‘yxatida ishlaydi; natija bosilganda tegishli bo‘limga o‘tadi.
- To‘liq rasmiy qonunchilik bazasi hali ulanmaganligi interfeysda ochiq ko‘rsatilgan. Bu versiya Lex.uz’dagi barcha hujjatlarni qamrab olmaydi.
- Keyingi bosqich: ruxsat etilgan rasmiy ma’lumot manbasini aniqlash, hujjatlar bazasini tuzish, amaldagi tahrir va kuchga kirish sanasini saqlash, so‘ng AI javoblarini manbalarga bog‘lash.
